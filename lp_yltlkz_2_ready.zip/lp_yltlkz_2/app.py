from flask import Flask
from extensions import db, jwt
from controllers.auth_controller import auth_bp
from controllers.hall_controller import hall_bp
from controllers.session_controller import session_bp

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/cinema.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'supersecret'

db.init_app(app)
jwt.init_app(app)

app.register_blueprint(auth_bp)
app.register_blueprint(hall_bp)
app.register_blueprint(session_bp)

@app.route('/')
def home():
    return '🎬 API кинотеатра работает!'

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
