from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from models.session import Session
from extensions import db

session_bp = Blueprint('sessions', __name__, url_prefix='/sessions')

@session_bp.route('/', methods=['POST'])
@jwt_required()
def create_session():
    data = request.get_json()
    session = Session(movie_id=data['movieId'], hall_id=data['hallId'], start_time=data['startTime'], price=data['price'])
    db.session.add(session)
    db.session.commit()
    return jsonify({'message': 'Сеанс успешно создан', 'id': session.id})
