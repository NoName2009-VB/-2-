from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from models.hall import Hall
from extensions import db

hall_bp = Blueprint('halls', __name__, url_prefix='/halls')

@hall_bp.route('/', methods=['POST'])
@jwt_required()
def create_hall():
    data = request.get_json()
    hall = Hall(name=data['name'], rows=data['rows'], seats_per_row=data['seatsPerRow'])
    db.session.add(hall)
    db.session.commit()
    return jsonify({'message': 'Зал успешно создан', 'id': hall.id})
